from rest_framework import status as statuss
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import TvFileGetSerializer, TvStatusSerializer, TvStorageSerializer, TvLoginSerializer
from sop.models import DisplayTV, ProductionLine, MediaContent, StatusTV, StorageTV
from django.contrib.auth import authenticate
from django.utils.timezone import localtime
from datetime import timedelta
from django.utils import timezone


# class TvFileGetSerializerView(APIView):

    # def get(self, request, format=None):
    #     serializer = TvFileGetSerializer(data=request.data) 
    #     if serializer.is_valid():
    #         tv_id = serializer.data["tv_id"]

    #         display_tv_obj = DisplayTV.objects.get(id=tv_id)

    #         ProductionLines = ProductionLine.objects.filter(display_tv=display_tv_obj)

    #         active_line_list = []

    #         for line in ProductionLines:
    #             if line.active_line == 1:
    #                 active_line_list.append(line.id)
            
    #         if active_line_list:

    #             active_line_obj = ProductionLine.objects.get(id=active_line_list[0])

    #             result = active_line_obj.media_contents.all()

    #             required_media_content_obj = []

    #             for item in result:
    #                 if item.display_tv.id == tv_id:
    #                     required_media_content_obj.append(item.id)


    #             final_media_content_obj = MediaContent.objects.get(id=required_media_content_obj[0])

    #             final_queryset = final_media_content_obj.files.all()




    #             response = []

    #             for item in final_queryset:
    #                 response.append(
    #                     {
    #                         "id":item.id,
    #                         "user":tv_id,
    #                         "file_uploaded":f"http://127.0.0.1:8000{item.file.url}",
    #                         "duration":final_media_content_obj.duration,
    #                     }
    #                 )

    #             print(response, type(response))

    #             return Response(response, status=status.HTTP_200_OK)
    #         else:
    #             response = {
    #                 "Status":"Failed",
    #                 f"{tv_id}":"this tv does not associate with active line."
    #             }
    #             return Response(response, status=status.HTTP_400_BAD_REQUEST) 


class TvFileGetSerializerView(APIView):

    def get(self, request, tv_id, format=None):

        display_tv_obj = DisplayTV.objects.get(id=tv_id)

        ProductionLines = ProductionLine.objects.filter(display_tv=display_tv_obj)

        active_line_list = []

        for line in ProductionLines:
            if line.active_line == 1:
                active_line_list.append(line.id)
        
        if active_line_list:

            active_line_obj = ProductionLine.objects.get(id=active_line_list[0])

            result = active_line_obj.media_contents.all()

           

            required_media_content_obj = []

            for item in result:
                if item.display_tv.id == tv_id:
                    required_media_content_obj.append(item.id)


            
            print("What is inside it ?", required_media_content_obj)

            response = []

            for media_content_id in required_media_content_obj:



                final_media_content_obj = MediaContent.objects.get(id=media_content_id)

                final_queryset = final_media_content_obj.files.all()

                

                for item in final_queryset:
                    
                    
                    # Get MediaContent update time
                    media_content_updated = final_media_content_obj.updated_at
                    

                    # MediaFile update time (NEW)
                    media_file_updated = item.updated_at

                    # Get VolumeTV update time
                    volume_updated = display_tv_obj.volumetv.updated_at if hasattr(display_tv_obj, "volumetv") else media_content_updated


                    # Choose the latest time
                    last_updated_time = max(media_content_updated, media_file_updated, volume_updated)

                    # Format for API
                    last_updated_formatted = localtime(last_updated_time).strftime("%d-%m-%Y %I:%M:%S %p")
                    
                    response.append(
                        {
                            "id":item.id,
                            "user":tv_id,
                            "file_uploaded":f"https://sop.taxinq.com{item.file.url}",
                            "duration":final_media_content_obj.duration,
                            "sequence":item.order,
                            "volume":display_tv_obj.volumetv.volume_tv,
                            "last_updated":last_updated_formatted,
                        }
                    )

            return Response(response, status=statuss.HTTP_200_OK)
        else:
            response = {
                "Status":"Failed",
                f"{tv_id}":"this tv does not associate with active line."
            }
            return Response(response, status=statuss.HTTP_400_BAD_REQUEST) 
        



# TV Status Serializer Api

# TV Status Serializer Api




class TvStatusSerializerView(APIView):

    def post(self, request, format=None):
        serializer = TvStatusSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        tvid = serializer.validated_data['tvid']
        status = serializer.validated_data['status']

        displaytv_obj = DisplayTV.objects.get(id=tvid.id)

        # ✅ Get existing row or create new one
        status_obj, created = StatusTV.objects.get_or_create(
            tvid=displaytv_obj,
            defaults={"status": status}
        )

        # If record already existed, update it
        if not created:
            previous_updated_time = status_obj.updated_time

            StatusTV.objects.filter(id=status_obj.id).update(
                status=status,
                updated_time=timezone.now()
            )

            status_obj.refresh_from_db()

            # ✅ Time difference logic (unchanged)
            if status_obj.updated_time - previous_updated_time > timedelta(minutes=5):
                StatusTV.objects.filter(id=status_obj.id).update(status="OFFLINE")
                status_obj.refresh_from_db()

        # ✅ Prepare response
        response_serializer = TvStatusSerializer(status_obj)
        data = response_serializer.data

        data["time"] = timezone.localtime(status_obj.time).strftime(
            "%d %b %Y, %I:%M:%S %p"
        )
        data["updated_time"] = timezone.localtime(status_obj.updated_time).strftime(
            "%d %b %Y, %I:%M:%S %p"
        )

        return Response(data, status=statuss.HTTP_200_OK)

    


# TV Storage Serializer Api

class TvStorageSerializerView(APIView):

    def post(self, request, format=None):
        serializer = TvStorageSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        tvid = serializer.validated_data['tvid']
        storage = serializer.validated_data['storage']

        obj, created = StorageTV.objects.update_or_create(
            tvid=tvid,
            defaults={'storage': storage}
        )

        response_serializer = TvStorageSerializer(obj)
        data = response_serializer.data

        # format datetime here
        if obj:
            data['time'] = localtime(obj.time).strftime("%d %b %Y, %I:%M:%S %p")
            data['updated_time'] = localtime(obj.updated_time).strftime("%d %b %Y, %I:%M:%S %p")

        return Response(
            data,
            status=statuss.HTTP_200_OK if not created else statuss.HTTP_201_CREATED
        )




# TV Login Serializer Api

class TvLoginSerializerView(APIView):


    def post(self, request, format=None):
        serializer = TvLoginSerializer(data=request.data) 
        if serializer.is_valid():
            uusername = serializer.data["username"]
            upass = serializer.data["password"]
            user = authenticate(username=uusername,password=upass)
            if user !=None:
                print("Valid user !!")

                response = {
                    "Status":"Success",
                    "Message":"Valid Credentials to login",
                    "User":user.username,
                    "TvID":user.displaytv_profile.id,
                    "TvName":user.displaytv_profile.display_number,
                }
                return Response(response, status=statuss.HTTP_200_OK)
            else:
                response = {
                    "Status":"Failed",
                    "Message":"Invalid Credentials",
                    "phone":uusername,
                    "password":upass,
                }
                return Response(response, status=statuss.HTTP_401_UNAUTHORIZED)
        else:
            response = {"Status":"Failed","Errors":serializer.errors}
            return Response(response, status=statuss.HTTP_400_BAD_REQUEST)

